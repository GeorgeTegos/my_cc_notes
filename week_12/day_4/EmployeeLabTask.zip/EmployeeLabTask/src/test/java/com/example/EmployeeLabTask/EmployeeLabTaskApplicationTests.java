package com.example.EmployeeLabTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeLabTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
