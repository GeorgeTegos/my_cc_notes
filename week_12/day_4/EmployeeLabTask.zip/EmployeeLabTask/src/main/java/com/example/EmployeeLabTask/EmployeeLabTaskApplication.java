package com.example.EmployeeLabTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeLabTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeLabTaskApplication.class, args);
	}

}
